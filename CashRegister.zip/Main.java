import java.util.ArrayList;
import java.util.Scanner;
public class Test{
ArrayList prices = new ArrayList();
  
public void additem(int num){ //it will add item
prices.add(num);
}
public int getTotal(){//calculating total
int total=0;
for(int i=0;i<prices.size();i++){
total = total + (int)prices.get(i);
}
return total;
}
public int getCount(){//grrtting total objects store till now
return prices.size();
}
public void display(){//printing all prices
System.out.println("Prices stored are: " + prices);
}
public void clear(){//claer data
prices.clear();
}
public static void main(String args[]){
Test pricesStore = new Test();
Scanner sc = new Scanner(System.in);
//scanner object decalred to read input from user
//printing menu
while(true){
System.out.println("1.addItem 2.getTotal 3.getCount 4.display 5.clear 6.exit");
int choice = sc.nextInt();//reading choice
if(choice == 1){
System.out.println("Enter price: ");
int price = sc.nextInt();
pricesStore.additem(price);
}
else if(choice == 2){
System.out.println("The total is: "+pricesStore.getTotal());
}
else if(choice == 3){
System.out.println("The count is: "+pricesStore.getCount());
}
else if(choice == 4){
pricesStore.display();
}
else if(choice == 5){
pricesStore.clear();
}
else{//safely exiting
System.out.println("Byee!!");
break;
}
}
}
}